import { Planta } from "./Planta"

export class Medicion{
    idMedicion:number = 0
    Humedad:string = ""
    Temperatura:string = ""
    Ph:string = ""
    fecha_med:Date = new Date()
    planta:Planta = new Planta();
}