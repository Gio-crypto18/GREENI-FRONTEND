
import { TipoInteraccion  } from "./TipoInteraccion"
import { Usuario } from "./Usuario"

export class Interaccion{
    interaccion_id:number = 0
    Descripcion:string =""
    tipoInteraccion:TipoInteraccion = new TipoInteraccion();
    Fecha_pub:Date =new Date()
    usuario:Usuario =new Usuario();
}