import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {
  private readonly apiUrl = 'https://openrouter.ai/api/v1/chat/completions';
  private readonly apiKey = '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';

  constructor(private http: HttpClient) {}

  getChatResponse(pregunta: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': window.location.origin,
      'X-Title': 'GreenImpact App'
    });

    // Prueba con diferentes modelos
    const body = {
      model: 'mistralai/mistral-7b-instruct:free', // ← Cambié el modelo
      messages: [
        {
          role: 'user',  // ← Probemos sin system message primero
          content: `Eres un experto en medio ambiente y jardinería. Responde esta pregunta: ${pregunta}`
        }
      ],
      max_tokens: 300,
      temperature: 0.7
    };

    console.log('🔗 Enviando solicitud a OpenRouter...');
    console.log('📝 Pregunta:', pregunta);
    console.log('🔐 Headers:', headers);
    console.log('📦 Body:', JSON.stringify(body, null, 2));

    return this.http.post(this.apiUrl, body, { headers }).pipe(
      tap(response => {
        console.log('✅ Respuesta recibida:', response);
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('❌ Error completo:', error);
        console.error('🔍 Status:', error.status);
        console.error('🔍 Error message:', error.message);
        console.error('🔍 Error response:', error.error);
        
        return throwError('Ocurrió un error al consultar la IA. Revisa la consola para más detalles.');
      })
    );
  }
}