import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, RouterOutlet } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { Sidebar } from "./components/sidebar/sidebar";
import { HomeComponent } from "./components/home/home";
import { Planta } from './components/plantas/plantas';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HttpClientModule, Sidebar,RouterModule,RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent {
  title = 'GREENI';
}