import { Routes } from '@angular/router';
import { rolinsertar } from './components/rol/rolinsertar/rolinsertar';
import { PlantIdentifierComponent } from './components/apidiagnostico/apidiagnostico';
import { Rol } from './components/rol/rol';



import { Especieregistrar } from './components/especie/especieregistrar/especieregistrar';
import { Especie } from './components/especie/especie';
import { TipoInteraccion } from './components/tipo-interaccion/tipo-interaccion';
import { Tipointeraccionrinsertar } from './components/tipo-interaccion/tipointeraccionrinsertar/tipointeraccionrinsertar';
import { Diagnostico } from './components/diagnostico/diagnostico';
import { Diagnosticorinsertar } from './components/diagnostico/diagnosticorinsertar/diagnosticorinsertar';
import { EstadoRecordatorio } from './components/estado-recordatorio/estado-recordatorio';
import { Estadorecordatorioinsertar } from './components/estado-recordatorio/estadorecordatorioinsertar/estadorecordatorioinsertar';
import { HomeComponent } from './components/home/home';
import { CalendarComponent } from './components/calendar/calendar';
import { GuidesComponent } from './components/guia/guia';
import { Guiainsertar } from './components/guia/guiainsertar/guiainsertar';
import { ComunidadComponent } from './components/comunidad/comunidad';
import { PerfilComponent } from './components/perfil/perfil';
import { Diagnosticolistar } from './components/diagnostico/diagnosticolistar/diagnosticolistar';
import { Guialistar } from './components/guia/guialistar/guialistar';
import { Especielistar } from './components/especie/especielistar/especielistar';
import { Tipointeraccionlistar } from './components/tipo-interaccion/tipointeraccionlistar/tipointeraccionlistar';
import { Estadorecordatoriolistar } from './components/estado-recordatorio/estadorecordatoriolistar/estadorecordatoriolistar';
import { Usuario } from './components/usuario/usuario';
import { Usuariolistar } from './components/usuario/usuariolistar/usuariolistar';
import { Usuarioregistrar } from './components/usuario/usuarioregistrar/usuarioregistrar';
import { Rollistar } from './components/rol/rollistar/rollistar';
import { Recordatoriolistar } from './components/recordatorio/recordatoriolistar/recordatoriolistar';
import { Recordatorioregistrar } from './components/recordatorio/recordatorioregistrar/recordatorioregistrar';
import { Recordatorio } from './components/recordatorio/recordatorio';
import { Interaccion } from './components/interaccion/interaccion';
import { Interaccionlistar } from './components/interaccion/interaccionlistar/interaccionlistar';
import { Interaccionregistrar } from './components/interaccion/interaccionregistrar/interaccionregistrar';
import { Planta } from './components/plantas/plantas';
import { Plantaslistar } from './components/plantas/plantaslistar/plantaslistar';
import { Plantainsertar } from './components/plantas/plantainsertar/plantainsertar';
import { Medicionlistar } from './components/medicion/medicionlistar/medicionlistar';
import { Medicionregistrar } from './components/medicion/medicionregistrar/medicionregistrar';
import { Diagnosticozona } from './components/diagnosticozona/diagnosticozona';
import { Plantazona } from './components/plantazona/plantazona';
import { Guiazona } from './components/guiazona/guiazona';
import { Medicion } from './components/medicion/medicion';
import { Tratamiento } from './components/tratamiento/tratamiento';
import { Tratamientolistar } from './components/tratamiento/tratamientolistar/tratamientolistar';
import { Tratamientoregistrar } from './components/tratamiento/tratamientoregistrar/tratamientoregistrar';




export const routes: Routes = [
  { 
    path: '', 
    component: HomeComponent
  },
{ 
  path: 'planta', component: Planta ,
  children: [
    { path: 'listar', component: Plantaslistar },
    { path: 'agregar', component: Plantainsertar },
    { path: 'editar/:id', component: Plantainsertar }
  ]
},
   { path: 'diagnostico', component: Diagnostico,
        children: [
          { path: '', component: Diagnosticolistar },
          { path: 'agregar', component: Diagnosticorinsertar },
          { path: 'editar/:id', component: Diagnosticorinsertar }
        ]
  },
     { path: 'usuario', component: Usuario,
        children: [
          { path: 'listar', component: Usuariolistar },
          { path: 'agregar', component: Usuarioregistrar },
          { path: 'editar/:id', component: Usuarioregistrar }
        ]
  },


{ path: 'medicion', component: Medicion ,
        children: [
          { path: 'listar', component: Medicionlistar },
          { path: 'agregar', component: Medicionregistrar },
          { path: 'editar/:id', component: Medicionregistrar }
        ]
  },
{ 
  path: 'personalizadas', 
  component: GuidesComponent
},
{ 
  path: 'guia', 
  component: GuidesComponent,
  children: [
    { path: 'listar', component: Guialistar },  
    { path: 'agregar', component: Guiainsertar },  
    { path: 'editar/:id', component: Guiainsertar }
  ]
},
{ path: 'rol', component: Rol,
        children: [
          { path: 'listar', component: Rollistar },  
          { path: 'agregar', component: rolinsertar },
          { path: 'editar/:id', component: rolinsertar }
        ]
      },
{ path: 'especie', component: Especie,
 children: [
  { path: 'listar', component: Especielistar },
 { path: 'agregar', component: Especieregistrar },
{ path: 'editar/:id', component: Especieregistrar }
  ]
},
{ path: 'tipointeraccion', component: TipoInteraccion,
        children: [
          { path: 'listar', component: Tipointeraccionlistar },
          { path: 'agregar', component: Tipointeraccionrinsertar },
          { path: 'editar/:id', component: Tipointeraccionrinsertar }
        ]
      },
{ path: 'recordatorio', component: Recordatorio,
        children: [
          { path: 'listar', component: Recordatoriolistar },
          { path: 'agregar', component: Recordatorioregistrar },
          { path: 'editar/:id', component: Recordatorioregistrar }
        ]
  },
  { path: 'interaccion', component: Interaccion,
        children: [
          { path: 'listar', component: Interaccionlistar },
          { path: 'agregar', component: Interaccionregistrar },
          { path: 'editar/:id', component: Interaccionregistrar }
        ]
  },
{ path: 'estadorecordatorio', component: EstadoRecordatorio,
        children: [
          { path: 'listar', component: Estadorecordatoriolistar },
          { path: 'agregar', component: Estadorecordatorioinsertar },
          { path: 'editar/:id', component: Estadorecordatorioinsertar }
        ]
      },
{ 

  
  path: 'medicion', component: Medicion ,
  children: [
    { path: 'listar', component: Medicionlistar },
    { path: 'agregar', component: Medicionregistrar },
    { path: 'editar/:id', component: Medicionregistrar }
  ]
},

{ path: 'tratamiento', component: Tratamiento ,
        children: [
          { path: 'listar', component: Tratamientolistar },
          { path: 'agregar', component: Tratamientoregistrar },
          { path: 'editar/:id', component: Tratamientoregistrar }
        ]
  },
  { 
    path: 'calendar', 
    component: CalendarComponent
  },
  { 
    path: 'comunidad', 
    component: ComunidadComponent
  },
  { 
    path: 'perfil', 
    component:PerfilComponent
  },
  { path: 'apidiagnostico', component: PlantIdentifierComponent },

  { path: 'diagnosticozona', component: Diagnosticozona },

   { path: 'plantazona', component: Plantazona },

  { path: 'guiazona', component: Guiazona }

];