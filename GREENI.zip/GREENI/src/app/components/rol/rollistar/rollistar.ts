import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Rolservice } from '../../../services/rolservice';
import { Rol } from '../../../models/Rol';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';


@Component({
  selector: 'app-rollistar',
  imports: [
    MatTableModule, 
    MatIconModule,
    MatButtonModule,
    RouterLink
  
  ],
  templateUrl: './rollistar.html',
  styleUrl: './rollistar.css',
})
export class Rollistar implements OnInit {
  dataSource: MatTableDataSource<Rol> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4'];


  constructor(private rS: Rolservice) {}

  ngOnInit(): void {

    this.rS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });

    this.rS.getList().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });

  }

  eliminar(id: number) {
    this.rS.deleteD(id).subscribe(data=> {
      this.rS.list().subscribe((data) => {
        this.rS.setList(data);
      })
    })
  }
}