import { Component } from '@angular/core';

@Component({
  selector: 'app-guiafav',
  imports: [],
  templateUrl: './guiafav.html',
  styleUrl: './guiafav.css',
})
export class Guiafav {

}
