import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Medicion } from '../../../models/Medicion';
import { Planta } from '../../../models/Planta';
import { Medicionservice } from '../../../services/medicionservice';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { PlantaService } from '../../../services/plantaservice';

@Component({
  selector: 'app-medicionregistrar',
  imports: [MatSelectModule,MatInputModule,MatButtonModule,ReactiveFormsModule,MatNativeDateModule,MatIconModule],
  templateUrl: './medicionregistrar.html',
  styleUrl: './medicionregistrar.css',
})
export class Medicionregistrar implements OnInit {
  form: FormGroup = new FormGroup({});
  edicion: boolean = false;
  id: number = 0;
  med: Medicion = new Medicion();
  ListaPlantas: Planta[] = [];

  constructor(
    private mS: Medicionservice,
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private pS: PlantaService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((data: Params) => {
      this.id = data['id'];
      this.edicion = data['id'] != null;
      this.init();
    });

    this.pS.list().subscribe((data) => {
      this.ListaPlantas = data;
    });


    this.form = this.formBuilder.group({
      codigo: [''],
      humedad: ['', Validators.required],
      temperatura: ['', Validators.required],
      ph: ['', Validators.required],
      planta: ['', Validators.required]
    });
  }

  obtenerFechaActual(): Date {
    return new Date(); 
  }

  aceptar(): void {
  if (this.form.valid) {
    this.med.idMedicion = this.form.value.codigo;
    this.med.Humedad = this.form.value.humedad;
    this.med.Temperatura = this.form.value.temperatura;
    this.med.Ph = this.form.value.ph;
    this.med.fecha_med = new Date();
    this.med.planta = new Planta();
    this.med.planta.idPlanta = this.form.value.planta;

    if (this.edicion) {
      this.mS.update(this.med).subscribe(() => {
        this.mS.list().subscribe((data) => {
          this.mS.setList(data);
        });
      });
    } else {
      this.mS.insert(this.med).subscribe(() => {
        this.mS.list().subscribe((data) => {
          this.mS.setList(data);
        });
      });
    }

    this.router.navigate(['medicion/listar']);
  }
}


  init() {
    if (this.edicion) {
      this.mS.listId(this.id).subscribe((data) => {
        this.form =new FormGroup({
          codigo: new FormControl(data.idMedicion),
          humedad: new FormControl(data.Humedad),
          ph: new FormControl(data.Ph),
          temperatura: new FormControl(data.Temperatura),
          planta: new FormControl(data.planta.idPlanta),
        });
      });
    }
  }
}