import { Component, OnInit } from '@angular/core';

import { Medicion } from '../../../models/Medicion';
import { Medicionservice } from '../../../services/medicionservice';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';

@Component({
  selector: 'app-medicionlistar',
  imports: [MatTableModule,CommonModule,MatIconModule,RouterLink,MatButtonModule,RouterLink],
  templateUrl: './medicionlistar.html',
  styleUrl: './medicionlistar.css',
})
export class Medicionlistar implements OnInit {
  dataSource: MatTableDataSource<Medicion> = new MatTableDataSource();
  displayedColumns: string[] = ['a', 'b', 'c', 'd','e','FK2','i','j'];

  constructor(private mS: Medicionservice) {}

  ngOnInit(): void {

    this.mS.list().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data)
    })
    this.mS.getList().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data)
    })
  }  
  eliminar(id:number){
    this.mS.delete(id).subscribe(data=>{
      this.mS.list().subscribe(data=>{
        this.mS.setList(data)
      })
    })
  }
}
