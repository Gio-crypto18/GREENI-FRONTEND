import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';
import { EstadoRecordatorio } from '../../../models/EstadoRecordatorio';
import { EstadoRecordatorioservice } from '../../../services/estado_recordatorioservice';

@Component({
  selector: 'app-estadorecordatoriolistar',
  imports: [MatTableModule,MatIconModule,MatButtonModule,RouterLink],
  templateUrl: './estadorecordatoriolistar.html',
  styleUrl: './estadorecordatoriolistar.css',
})
export class Estadorecordatoriolistar {
  dataSource: MatTableDataSource<EstadoRecordatorio> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4'];

   constructor(private dS: EstadoRecordatorioservice) {}

  ngOnInit(): void {
    this.dS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
    this.dS.getList().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }

  eliminar(id: number) {
    this.dS.delete(id).subscribe(data=>{
      this.dS.list().subscribe(data=>{
        this.dS.setList(data)
      })
    })
  }
}
