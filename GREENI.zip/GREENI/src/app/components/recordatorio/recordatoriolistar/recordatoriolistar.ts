import { CommonModule } from '@angular/common';
import { Component,OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';
import { Recordatorio } from '../../../models/Recordatorio';
import { Recordatorioservice } from '../../../services/recordatorioservice';

@Component({
  selector: 'app-recordatoriolistar',
  imports: [MatTableModule,CommonModule,MatIconModule,RouterLink,MatButtonModule],
  templateUrl: './recordatoriolistar.html',
  styleUrl: './recordatoriolistar.css',
})
export class Recordatoriolistar implements OnInit {
  dataSource: MatTableDataSource<Recordatorio> = new MatTableDataSource();
  displayedColumns: string[] = ['a', 'b', 'c','d','usuario','estadorecordatorio','i','j'];

  constructor(private rS: Recordatorioservice) {}
  ngOnInit(): void {

    this.rS.list().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data)
    })
    this.rS.getList().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data)
    })
  }  
  eliminar(id:number){
    this.rS.delete(id).subscribe(data=>{
      this.rS.list().subscribe(data=>{
        this.rS.setList(data)
      })
    })
  }
}
