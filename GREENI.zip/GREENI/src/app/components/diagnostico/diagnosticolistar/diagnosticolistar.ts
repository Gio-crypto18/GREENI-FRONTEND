import { Component, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';
import { Diagnostico } from '../../../models/Diagnostico';
import { Diagnosticoservice } from '../../../services/diagnosticoservice';

@Component({
  selector: 'app-diagnosticolistar',
  imports: [MatTableModule,MatIconModule,MatButtonModule,RouterLink],
  templateUrl: './diagnosticolistar.html',
  styleUrl: './diagnosticolistar.css',
})
export class Diagnosticolistar implements OnInit {
  dataSource: MatTableDataSource<Diagnostico> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'];

constructor(private dS: Diagnosticoservice) {}
ngOnInit(): void {
    this.dS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
    this.dS.getList().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }

  eliminar(id: number) {
    this.dS.delete(id).subscribe(data=>{
      this.dS.list().subscribe(data=>{
        this.dS.setList(data)
      })
    })
  }
}
