import { Component,OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';
import { TipoInteraccion } from '../../../models/TipoInteraccion';
import { TipoInteraccionservice } from '../../../services/tipointeraccionservice';

@Component({
  selector: 'app-tipointeraccionlistar',
  imports: [MatTableModule,MatIconModule,MatButtonModule,RouterLink],
  templateUrl: './tipointeraccionlistar.html',
  styleUrl: './tipointeraccionlistar.css',
})
export class Tipointeraccionlistar implements OnInit {

  dataSource: MatTableDataSource<TipoInteraccion> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4'];
  constructor(private dS: TipoInteraccionservice) {}

   ngOnInit(): void {
    this.dS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
    this.dS.getList().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }

  eliminar(id: number) {
    this.dS.delete(id).subscribe(data=>{
      this.dS.list().subscribe(data=>{
        this.dS.setList(data)
      })
    })
  }
}
