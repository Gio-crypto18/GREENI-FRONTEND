import { Component } from '@angular/core';
import { WeatherComponent } from '../weather/weather';
import { RouterModule } from '@angular/router';
import { MatIcon } from '@angular/material/icon';


@Component({
  selector: 'app-home',
  imports: [WeatherComponent,RouterModule,MatIcon], 
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class HomeComponent {
  
  toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
      sidebar.classList.toggle('active');
    }
  }
}