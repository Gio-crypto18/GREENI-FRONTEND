import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

interface User {
  userId: string;
  fullName: string;
  email: string;
  avatarUrl?: string;
  role: string;
  status: string;
  bio: string;
  joinedAt: string;
}

interface Notifications {
  reminders: boolean;
  interactions: boolean;
  friends: boolean;
  newsletter: boolean;
}

interface Feedback {
  message: string;
  class: string;
}

@Component({
  selector: 'app-perfil',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './perfil.html',
  styleUrls: ['./perfil.css']
})
export class PerfilComponent implements OnInit {
  activeTab: string = 'perfil';
  user: User = {
    userId: '',
    fullName: '',
    email: '',
    role: 'Plantlover',
    status: 'Activo',
    bio: '',
    joinedAt: ''
  };

  profileForm!: FormGroup;
  passwordForm!: FormGroup;

  notifications: Notifications = {
    reminders: true,
    interactions: true,
    friends: true,
    newsletter: false
  };

  notificationsChanged = false;
  originalNotifications: Notifications = { ...this.notifications };

  showCurrentPassword = false;
  showNewPassword = false;
  showConfirmPassword = false;

  profileFeedback: Feedback = { message: '', class: '' };
  passwordFeedback: Feedback = { message: '', class: '' };
  notificationsFeedback: Feedback = { message: '', class: '' };

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.loadUserData();
    this.initForms();
  }

  initForms(): void {
    this.profileForm = this.fb.group({
      userId: [{ value: this.user.userId, disabled: true }],
      joinedAt: [{ value: this.user.joinedAt, disabled: true }],
      fullName: [this.user.fullName, [Validators.required, Validators.minLength(2)]],
      email: [this.user.email, [Validators.required, Validators.email]],
      status: [this.user.status],
      role: [{ value: this.user.role, disabled: true }],
      bio: [this.user.bio]
    });

    this.passwordForm = this.fb.group({
      currentPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('newPassword')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return newPassword === confirmPassword ? null : { passwordMismatch: true };
  }

  loadUserData(): void {
    this.user = {
      userId: 'USR-001',
      fullName: 'Carol García',
      email: 'carol123@gmail.com',
      role: 'plantlover',
      status: 'Activo',
      bio: 'Amante de las plantas y la naturaleza. Especialista en plantas de interior.',
      joinedAt: '15 Ene 2024'
    };
  }

  // Métodos de UI
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

  toggleSidebar(): void {
    console.log('Toggle sidebar');
  }

  // Métodos de perfil
  saveProfile(): void {
    if (this.profileForm.valid) {
      const formData = this.profileForm.getRawValue();
      this.user = { ...this.user, ...formData };
      
      this.showFeedback('profile', 'Perfil actualizado correctamente', 'success');
      this.profileForm.markAsPristine();
    }
  }

  createNewUser(): void {
    console.log('Crear nuevo usuario');
    // Lógica para crear nuevo usuario
  }

  deleteUser(): void {
    if (confirm('¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.')) {
      console.log('Eliminar usuario');
      // Lógica para eliminar usuario
    }
  }

  // Métodos de seguridad
  changePassword(): void {
    if (this.passwordForm.valid) {
      console.log('Cambiando contraseña...');
      this.showFeedback('password', 'Contraseña actualizada correctamente', 'success');
      this.passwordForm.reset();
    }
  }

  togglePasswordVisibility(field: string): void {
    switch (field) {
      case 'current':
        this.showCurrentPassword = !this.showCurrentPassword;
        break;
      case 'new':
        this.showNewPassword = !this.showNewPassword;
        break;
      case 'confirm':
        this.showConfirmPassword = !this.showConfirmPassword;
        break;
    }
  }

  // Métodos de notificaciones
  onNotificationChange(key: keyof Notifications, event: Event): void {
    const input = event.target as HTMLInputElement;
    this.notifications[key] = input.checked;
    this.checkNotificationsChanges();
  }

  checkNotificationsChanges(): void {
    this.notificationsChanged = JSON.stringify(this.notifications) !== JSON.stringify(this.originalNotifications);
  }

  saveNotifications(): void {
    this.originalNotifications = { ...this.notifications };
    this.notificationsChanged = false;
    this.showFeedback('notifications', 'Configuración de notificaciones guardada', 'success');
  }

  // Métodos de utilidad
  onImageUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.user.avatarUrl = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  getUserInitials(): string {
    if (!this.user.fullName) return '—';
    return this.user.fullName
      .split(' ')
      .map(name => name[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  }

  getUserRoleDisplay(): string {
    const roleMap: { [key: string]: string } = {
      'plantlover': 'Plant Lover',
      'cientifico': 'Científico',
      'admin': 'Admin'
    };
    return roleMap[this.user.role] || 'Plant Lover';
  }

  getRoleBadgeClass(): string {
    return `role-badge ${this.user.role}`;
  }

  get avatarClass(): string {
    return `avatar-preview ${this.user.avatarUrl ? 'has-image' : 'no-image'}`;
  }

  showFeedback(type: string, message: string, feedbackClass: string): void {
    const feedbackMap: { [key: string]: Feedback } = {
      'profile': this.profileFeedback,
      'password': this.passwordFeedback,
      'notifications': this.notificationsFeedback
    };

    const feedback = feedbackMap[type];
    if (feedback) {
      feedback.message = message;
      feedback.class = feedbackClass;
      
      // Auto-ocultar después de 5 segundos
      setTimeout(() => {
        feedback.message = '';
      }, 5000);
    }
  }
}