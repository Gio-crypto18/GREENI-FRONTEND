import { Component, OnInit } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Tratamiento } from '../../../models/Tratamiento';
import { MatCellDef, MatHeaderCell, MatHeaderCellDef, MatHeaderRowDef, MatRowDef, MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Tratamientoservice } from '../../../services/tratamientoservice';
import { RouterLink } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-tratamientolistar',
  imports: [MatSelectModule,MatInputModule,MatButtonModule,ReactiveFormsModule,MatNativeDateModule,MatIconModule,RouterLink,MatCellDef,MatRowDef,MatHeaderCell,MatHeaderCellDef,MatHeaderRowDef,MatTableModule,DatePipe],
  templateUrl: './tratamientolistar.html',
  styleUrl: './tratamientolistar.css',
})
export class Tratamientolistar implements OnInit {

  dataSource: MatTableDataSource<Tratamiento> = new MatTableDataSource();

  displayedColumns: string[] = ['a', 'b', 'c','f','g','FK','i','j'];

 form: FormGroup = new FormGroup({});
  edicion: boolean = false;
  id: number = 0;
  tra: Tratamiento = new Tratamiento();

  listaTratamiento: Tratamiento[] = [];

  constructor(private tS: Tratamientoservice) {}
  ngOnInit(): void {

    this.tS.list().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data)
    })
    this.tS.getList().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data)
    })
  }  
  eliminar(id:number){
    this.tS.delete(id).subscribe(data=>{
      this.tS.list().subscribe(data=>{
        this.tS.setList(data)
      })
    })
  }

}
