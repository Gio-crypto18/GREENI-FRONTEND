import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { PlantaService } from '../../../services/plantaservice';
import { Planta } from '../../../models/Planta';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-plantaslistar',
  imports: [
    CommonModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    RouterLink,
    DatePipe
  ],
  templateUrl: './plantaslistar.html',
  styleUrl: './plantaslistar.css',
})
export class Plantaslistar implements OnInit {
  dataSource: MatTableDataSource<Planta> = new MatTableDataSource<Planta>();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'eli'];

  constructor(private pS: PlantaService) {}

  ngOnInit(): void {
    this.cargarDatos();
  }

  cargarDatos(): void {
    this.pS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }

  eliminar(id:number){
    this.pS.delete(id).subscribe(data=>{
      this.pS.list().subscribe(data=>{
        this.pS.setList(data)
      })
    })
  }
}